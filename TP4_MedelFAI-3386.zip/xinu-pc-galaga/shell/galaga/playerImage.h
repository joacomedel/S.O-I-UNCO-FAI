#ifndef PLAYERIMAGE_BITMAP_H
#define PLAYERIMAGE_BITMAP_H
extern const unsigned short playerImage[576];
#define PLAYERIMAGE_WIDTH 24
#define PLAYERIMAGE_HEIGHT 24
#endif