#ifndef GAMEOVER_BITMAP_H
#define GAMEOVER_BITMAP_H
extern const unsigned short gameover[38400];
#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160
#endif